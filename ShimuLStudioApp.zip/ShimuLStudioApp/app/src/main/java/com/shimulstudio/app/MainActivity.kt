package com.shimulstudio.app

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

const val BLOG = "https://shimulstudio.blogspot.com"
val CATEGORIES = listOf(
    "All", "AI", "Movie Review", "Books & Literature", "Education & Knowledge",
    "Career & Business", "World Explorer", "Lifestyle & Culture", "News & Sports"
)

data class Post(
    val title: String, val date: String, val html: String,
    val url: String, val image: String?, val labels: List<String>
)

suspend fun fetchPosts(label: String?, query: String?): List<Post> = withContext(Dispatchers.IO) {
    val base = "$BLOG/feeds/posts/default" +
        (if (label != null) "/-/" + URLEncoder.encode(label, "UTF-8").replace("+", "%20") else "")
    val q = if (!query.isNullOrBlank()) "&q=" + URLEncoder.encode(query, "UTF-8") else ""
    val conn = URL("$base?alt=json&max-results=30$q").openConnection().apply {
        connectTimeout = 10000; readTimeout = 10000
    }
    val text = conn.getInputStream().bufferedReader().use { it.readText() }
    val entries = JSONObject(text).getJSONObject("feed").optJSONArray("entry") ?: return@withContext emptyList()
    (0 until entries.length()).map { i ->
        val e = entries.getJSONObject(i)
        val html = e.optJSONObject("content")?.optString("\$t") ?: ""
        val links = e.getJSONArray("link")
        val url = (0 until links.length()).map { links.getJSONObject(it) }
            .firstOrNull { it.optString("rel") == "alternate" }?.optString("href") ?: BLOG
        val thumb = e.optJSONObject("media\$thumbnail")?.optString("url")
            ?.replace(Regex("/s\\d+(-c)?/"), "/s800/")
            ?: Regex("<img[^>]+src=\"([^\"]+)\"").find(html)?.groupValues?.get(1)
        val cats = e.optJSONArray("category")
        Post(
            title = e.getJSONObject("title").optString("\$t"),
            date = e.getJSONObject("published").optString("\$t").take(10),
            html = html, url = url, image = thumb,
            labels = if (cats == null) emptyList() else (0 until cats.length()).map { cats.getJSONObject(it).optString("term") }
        )
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

@Composable
fun App() {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 && dark -> dynamicDarkColorScheme(ctx)
        Build.VERSION.SDK_INT >= 31 -> dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize()) {
            var selected by remember { mutableStateOf<Post?>(null) }
            BackHandler(selected != null) { selected = null }
            val p = selected
            if (p == null) HomeScreen { selected = it } else DetailScreen(p) { selected = null }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (Post) -> Unit) {
    var label by remember { mutableStateOf("All") }
    var input by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }

    LaunchedEffect(label, query, retry) {
        loading = true; error = null
        runCatching { fetchPosts(if (label == "All") null else label, query) }
            .onSuccess { posts = it }
            .onFailure { error = "Couldn't load posts. Check your connection." }
        loading = false
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("ShimuL Studio", fontWeight = FontWeight.Bold) })
    }) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                placeholder = { Text("Search articles…") },
                singleLine = true, shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { query = input.trim() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(16.dp, 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(CATEGORIES) { c ->
                    FilterChip(selected = c == label, onClick = { label = c }, label = { Text(c) })
                }
            }
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                error != null -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                    Text(error!!); Spacer(Modifier.height(12.dp))
                    Button(onClick = { retry++ }) { Text("Retry") }
                }
                posts.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No posts found") }
                else -> LazyColumn(
                    contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) { items(posts) { PostCard(it) { onOpen(it) } } }
            }
        }
    }
}

@Composable
fun PostCard(p: Post, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column {
            if (p.image != null) AsyncImage(
                model = p.image, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(190.dp)
            )
            Column(Modifier.padding(16.dp)) {
                p.labels.firstOrNull()?.let {
                    Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(4.dp))
                Text(p.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    maxLines = 3, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Text(p.date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(p: Post, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val page = """
        <html><head><meta name="viewport" content="width=device-width,initial-scale=1">
        <style>
        body{font-family:sans-serif;line-height:1.75;padding:16px;margin:0;background:#fff;color:#222;word-wrap:break-word}
        img{max-width:100%;height:auto;border-radius:12px}
        h1{font-size:1.5em;line-height:1.3} .d{color:#888;font-size:.85em}
        @media(prefers-color-scheme:dark){body{background:#121212;color:#e6e6e6}a{color:#8ab4f8}}
        </style></head><body><h1>${p.title}</h1><div class="d">${p.date}</div>${p.html}</body></html>
    """.trimIndent()
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(p.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            actions = { TextButton(onClick = { share(ctx, p) }) { Text("Share") } }
        )
    }) { pad ->
        AndroidView(
            modifier = Modifier.fillMaxSize().padding(pad),
            factory = { c -> WebView(c).apply { loadDataWithBaseURL(p.url, page, "text/html", "utf-8", null) } }
        )
    }
}

fun share(ctx: Context, p: Post) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${p.title}\n${p.url}")
    }
    ctx.startActivity(Intent.createChooser(i, "Share"))
}
