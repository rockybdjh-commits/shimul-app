ShimuL Studio Android app (Kotlin + Jetpack Compose + Material 3)

Build the APK:
1. Install Android Studio (latest) and open this folder (File > Open).
2. Let Gradle sync (needs internet). Install the Android 16 (API 36) SDK if asked.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   APK: app/build/outputs/apk/debug/app-debug.apk

Android 17: install its SDK, then set compileSdk and targetSdk to 37 in app/build.gradle.kts.
App icon: right-click res > New > Image Asset, then add android:icon in the manifest.
